document.addEventListener('DOMContentLoaded', () => {
    const form = document.getElementById('smsForm');
    const floatingMessage = document.getElementById('floatingMessage');
    const loadingScreen = document.getElementById('loadingScreen');
    const drawer = document.getElementById('drawer');
    const openDrawerBtn = document.getElementById('openDrawer');
    const closeDrawerBtn = document.getElementById('closeDrawer');

    const toast = new bootstrap.Toast(floatingMessage, {
        autohide: true,
        delay: 5000
    });

    function showFloatingMessage(message, type) {
        const toastTitle = document.getElementById('toastTitle');
        const toastMessage = document.getElementById('toastMessage');

        toastTitle.textContent = type.charAt(0).toUpperCase() + type.slice(1);
        toastMessage.textContent = message;
        floatingMessage.className = `toast border-${type}`;
        toast.show();
    }

    function showLoadingScreen() {
        loadingScreen.classList.remove('d-none');
    }

    function hideLoadingScreen() {
        loadingScreen.classList.add('d-none');
    }

    form.addEventListener('submit', async (e) => {
        e.preventDefault();
        const number = document.getElementById('number').value.trim();
        const message = document.getElementById('message').value.trim();

        if (!number || !message) {
            showFloatingMessage('Please fill in both the phone number and message fields.', 'warning');
            return;
        }

        showLoadingScreen();

        try {
            const response = await fetch('/send-sms', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({ number, message }),
            });

            const data = await response.json();

            if (response.ok) {
                showFloatingMessage('SMS sent successfully!', 'success');
            } else {
                throw new Error(data.error || 'Failed to send the message');
            }
        } catch (error) {
            console.error('Error:', error);
            showFloatingMessage('Failed to send the message. Please try again later.', 'danger');
        } finally {
            hideLoadingScreen();
        }
    });

    // Drawer functionality
    openDrawerBtn.addEventListener('click', () => {
        drawer.classList.add('open');
    });

    closeDrawerBtn.addEventListener('click', () => {
        drawer.classList.remove('open');
    });

    // Close drawer when clicking outside
    document.addEventListener('click', (e) => {
        if (!drawer.contains(e.target) && e.target !== openDrawerBtn) {
            drawer.classList.remove('open');
        }
    });
});
