// Matrix Rain Effect
const canvas = document.getElementById('matrix-rain');
const ctx = canvas.getContext('2d');

function resizeCanvas() {
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;
}

resizeCanvas();

const matrix = "ABCDEFGHIJKLMNOPQRSTUVWXYZ123456789@#$%^&*()*&^%";
const matrixChars = matrix.split('');

const fontSize = 10;
let columns = canvas.width/fontSize;

let drops = [];
function initDrops() {
    drops = [];
    columns = canvas.width/fontSize;
    for(let x = 0; x < columns; x++) {
        drops[x] = 1;
    }
}

initDrops();

function drawMatrixRain() {
    ctx.fillStyle = 'rgba(0, 0, 0, 0.04)';
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    
    ctx.fillStyle = '#0F0';
    ctx.font = fontSize + 'px monospace';

    for(let i = 0; i < drops.length; i++) {
        const text = matrixChars[Math.floor(Math.random()*matrixChars.length)];
        ctx.fillText(text, i*fontSize, drops[i]*fontSize);
        
        if(drops[i]*fontSize > canvas.height && Math.random() > 0.975) {
            drops[i] = 0;
        }
        drops[i]++;
    }
}

// Drawer Functionality
const profilePhoto = document.getElementById('profile-photo');
const drawer = document.getElementById('drawer');
let isDrawerOpen = false;

function toggleDrawer(open) {
    isDrawerOpen = open;
    if (open) {
        drawer.style.left = '0';
        drawer.style.boxShadow = '2px 0 10px rgba(0, 255, 0, 0.3)';
    } else {
        drawer.style.left = '-280px';
        drawer.style.boxShadow = 'none';
    }
}

drawer.addEventListener('transitionend', function(e) {
    if (e.propertyName === 'left' && !isDrawerOpen) {
        drawer.style.boxShadow = 'none';
    }
});

profilePhoto.addEventListener('click', (e) => {
    e.stopPropagation();
    toggleDrawer(!isDrawerOpen);
});

// Close drawer when clicking outside
document.addEventListener('click', (e) => {
    if (isDrawerOpen && 
        !drawer.contains(e.target) && 
        e.target !== profilePhoto) {
        toggleDrawer(false);
    }
});

// Handle window resize
let resizeTimeout;
window.addEventListener('resize', () => {
    clearTimeout(resizeTimeout);
    resizeTimeout = setTimeout(() => {
        resizeCanvas();
        initDrops();
    }, 250);
});

// Start the matrix rain animation
setInterval(drawMatrixRain, 35);

// Smooth scrolling for navigation links
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();
        const section = document.querySelector(this.getAttribute('href'));
        if (section) {
            const yOffset = -20;
            const y = section.getBoundingClientRect().top + window.pageYOffset + yOffset;
            window.scrollTo({
                top: y,
                behavior: 'smooth'
            });
            
            // Close drawer on mobile after clicking a link
            if (window.innerWidth <= 768) {
                toggleDrawer(false);
            }
        }
    });
});

// Clock update function
function updateClock() {
    const now = new Date();
    document.getElementById('current-time').textContent = `Current Time: ${now.toLocaleString()}`;
}

// Initialize clock
setInterval(updateClock, 1000);
updateClock();

// Fetch and display IP address using Axios
async function fetchIPAddress() {
    try {
        const response = await axios.get('https://api-bdc.net/data/client-ip');
        const data = response.data;
        document.getElementById('ip-address').textContent = `IP Address: ${data.ipString} (${data.ipType})`;
    } catch (error) {
        console.error('Error fetching IP address:', error);
        document.getElementById('ip-address').textContent = 'IP Address: Unable to fetch';
    }
}

// Call the function to fetch and display IP address
fetchIPAddress();

