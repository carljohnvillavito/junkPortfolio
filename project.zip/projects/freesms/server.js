import express from 'express';
import path from 'path';
import { fileURLToPath } from 'url';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const port = 8080;

app.use(express.static('public'));
app.use(express.json());

app.get('/', (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.post('/send-sms', async (req, res) => {
  const { number, message } = req.body;
  const apiUrl = `https://api.kenliejugarap.com/freesmslbc/?number=${number}&message=${encodeURIComponent(message)}`;

  try {
    const response = await fetch(apiUrl);
    const data = await response.json();
    res.json(data);
  } catch (error) {
    res.status(500).json({ error: 'An error occurred while sending the SMS' });
  }
});

app.listen(port, () => {
  console.log(`Server running at http://localhost:${port}`);
});
